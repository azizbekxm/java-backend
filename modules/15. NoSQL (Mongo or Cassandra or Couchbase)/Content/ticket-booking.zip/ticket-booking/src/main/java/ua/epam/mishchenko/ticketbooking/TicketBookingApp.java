package ua.epam.mishchenko.ticketbooking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TicketBookingApp {

    public static void main(String[] args) {
        SpringApplication.run(TicketBookingApp.class, args);
    }
}
