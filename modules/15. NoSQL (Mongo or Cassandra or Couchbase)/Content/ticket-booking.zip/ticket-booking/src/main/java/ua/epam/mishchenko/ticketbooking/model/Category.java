package ua.epam.mishchenko.ticketbooking.model;

public enum Category {
    PREMIUM,
    STANDARD,
    BAR
}
