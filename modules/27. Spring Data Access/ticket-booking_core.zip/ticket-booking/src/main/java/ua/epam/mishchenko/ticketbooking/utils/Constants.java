package ua.epam.mishchenko.ticketbooking.utils;

import java.text.SimpleDateFormat;

public class Constants {

    public static final SimpleDateFormat DATE_FORMATTER = new SimpleDateFormat("dd-MM-yyyy HH:mm");

}
