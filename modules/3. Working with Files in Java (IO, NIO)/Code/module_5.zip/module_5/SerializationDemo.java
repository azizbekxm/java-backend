package com.company.module_5;

import java.io.*;

/**
 * Created by Alexey_Zinovyev on 15-Aug-16.
 */
public class SerializationDemo {
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        FileOutputStream fos = new FileOutputStream("temp.out");
        ObjectOutputStream oos = new ObjectOutputStream(fos);
        TestSerial ts = new TestSerial();
        ts.version = 1000;
        oos.writeObject(ts);
        oos.flush();
        oos.close();



        FileInputStream fis = new FileInputStream("temp.out");
        ObjectInputStream oin = new ObjectInputStream(fis);
        TestSerial ts1 = (TestSerial)oin.readObject();
        System.out.println(ts1.version);

    }
}

class TestParent implements Serializable{

}

class TestSerial extends TestParent  {
    public int version;
    public byte count = 0;
}
