package com.company.module_5;


import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;



/**
 * Created by Alexey_Zinovyev on 15-Aug-16.
 */
public class BookHandler extends DefaultHandler {
    @Override
    public void startElement (String uri, String localName,
                              String qName, org.xml.sax.Attributes attributes)
            throws org.xml.sax.SAXException{
        System.out.println("Tag " + qName);
        if(qName.equals("book")){
            System.out.println("Book id " + attributes.getValue("id"));
            System.out.println("Amount of pages " + attributes.getValue("pages"));
        }
    }

    @Override
    public void characters (char ch[], int start, int length)
            throws SAXException {
        System.out.println(new String(ch, start, length));
    }

}
