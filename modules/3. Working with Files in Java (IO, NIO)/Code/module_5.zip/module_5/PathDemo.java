package com.company.module_5;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * Created by Alexey_Zinovyev on 15-Aug-16.
 */
public class PathDemo {
    public static void main(String[] args) throws IOException {
        Path path = Paths.get("c:\\data\\4.txt");
        System.out.println(path.getFileName() + " in " + path.getFileSystem());
        System.out.println(path.getRoot());
        for(Path element : path){
            System.out.println(element);
        }

        Path pathDir = Paths.get("c:\\data\\newdir2");
       /* try {
            Path newDir = Files.createDirectory(pathDir);

        } catch (IOException e) {
            e.printStackTrace();
        }*/

        System.out.println(Files.isReadable(pathDir));
        System.out.println(Files.isWritable(pathDir));
        System.out.println(Files.isExecutable(pathDir));


        Files.deleteIfExists(path);

    }
}
