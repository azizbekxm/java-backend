package ua.epam.mishchenko.ticketbooking.utils;

import java.text.SimpleDateFormat;

/**
 * The type Constants.
 */
public class Constants {

    /**
     * The constant DATE_FORMATTER.
     */
    public static final SimpleDateFormat DATE_FORMATTER = new SimpleDateFormat("dd-MM-yyyy HH:mm");

}
