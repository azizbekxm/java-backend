package com.epam.cdp.caclulator

class KotlinCalculator {

    fun calculate(input: String): String = "0"
}