
rootProject.name = "KotlinCalculator"

