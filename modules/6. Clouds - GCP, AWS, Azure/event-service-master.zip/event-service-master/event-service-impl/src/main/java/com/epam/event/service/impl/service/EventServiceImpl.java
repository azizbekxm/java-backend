package com.epam.event.service.impl.service;

import com.epam.event.service.api.service.EventService;
import com.epam.event.service.dto.model.Event;
import com.epam.event.service.impl.repository.EventRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class EventServiceImpl implements EventService {

    private EventRepository repository;

    public EventServiceImpl(EventRepository repository) {
        this.repository = repository;
    }

    @Override
    public Event createEvent(Event event) {
        return repository.save(event);
    }

    @Override
    public Event updateEvent(Event event) {
        Optional<Event> existingEvent = repository.findById(event.getId());
        Event updatedEvent = null;
        if (existingEvent.isPresent()) {
            event.setId(existingEvent.get().getId());
            updatedEvent = repository.save(event);
        }
        return updatedEvent;
    }

    @Override
    public Event getEvent(long id) {
        return repository.findById(id).orElse(null);
    }

    @Override
    public void deleteEvent(long id) {
        repository.deleteById(id);
    }

    @Override
    public List<Event> getAllEvents() {
        List<Event> events = new ArrayList<>();
        repository.findAll().forEach(events::add);
        return events;
    }

    @Override
    public List<Event> getAllEventsByTitle(String title) {
        return repository.getEventsByTitle(title);
    }
}
