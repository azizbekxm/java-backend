CREATE TABLE IF NOT EXISTS events(
  id bigint AUTO_INCREMENT PRIMARY KEY,
  title      varchar(50) NOT NULL,
  place      varchar(50) NOT NULL,
  event_type varchar(50) NOT NULL,
  date_time  timestamp NOT NULL,
  speaker    varchar(100) NULL);

INSERT INTO events(title, place, event_type, date_time, speaker) VALUES
('IT conference', 'Sergeya Esenina 21', 'TECH_TALK', '2020-04-29 14:30:00.000', 'Keenan Cochran'),
('IT conference', 'Vysotskogo 17', 'TECH_TALK', '2020-05-05 11:45:00.000', 'Dave Kargen'),
('Social Networking development', 'Gorlovskaya 124/3', 'TECH_TALK', '2020-06-02 16:00:00.000', 'Siya Mcgrath'),
('Hackathon', 'Sosninykh Semi 5', 'TECH_TALK', '2020-05-17 12:20:00.000', 'Israel Alvarez'),
('Business plans', 'Vul. Grechneva, bld. 16', 'WORKSHOP', '2019-10-25 14:30:00.000', 'Dave Burris'),
('Discussion current process', 'Yaroslava Mudrogo 44', 'WORKSHOP', '2020-04-29 16:00:00.000', 'Sharon Farrington'),
('Plan of improvement', 'Degtyarevskaya 26', 'WORKSHOP', '2020-04-29 15:20:00.000', 'Hashir Kaye');
