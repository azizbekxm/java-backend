package com.epam.event.service.impl;

import com.epam.event.service.dto.model.Event;
import com.epam.event.service.dto.model.EventType;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

public class EventData {

    public static Event getEventPrototype() {
        LocalDateTime dateTime = LocalDateTime.of(2020, 5, 17, 12, 20);
        Event event = new Event();
        event.setTitle("Hackathon");
        event.setPlace("Sosninykh Semi 5");
        event.setEventType(EventType.TECH_TALK);
        event.setDateTime(dateTime);
        event.setSpeaker("Israel Alvarez");
        return event;
    }

    public static List<Event> getEventsPrototype() {
        LocalDateTime dateTime = LocalDateTime.of(2020, 4, 29, 14, 30);
        LocalDateTime dateTime2 = LocalDateTime.of(2020, 5, 5, 11, 45);
        LocalDateTime dateTime3 = LocalDateTime.of(2020, 6, 2, 16, 0);

        Event event = new Event();
        event.setId(1L);
        event.setTitle("Conference");
        event.setPlace("Sergeya Esenina 21");
        event.setEventType(EventType.TECH_TALK);
        event.setDateTime(dateTime);
        event.setSpeaker("Keenan Cochran");
        Event event2 = new Event();
        event2.setId(2L);
        event2.setTitle("Conference");
        event2.setPlace("Vysotskogo 17");
        event2.setEventType(EventType.TECH_TALK);
        event2.setDateTime(dateTime2);
        event2.setSpeaker("Dave Kargen");
        Event event3 = new Event();
        event3.setId(3L);
        event3.setTitle("Social Networking");
        event3.setPlace("Gorlovskaya 124/3");
        event3.setEventType(EventType.WORKSHOP);
        event3.setDateTime(dateTime3);
        event3.setSpeaker("Siya Mcgrath");

        return Arrays.asList(event, event2, event3);
    }
}
