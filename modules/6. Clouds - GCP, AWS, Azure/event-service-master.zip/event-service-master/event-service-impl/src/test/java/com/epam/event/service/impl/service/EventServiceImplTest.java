package com.epam.event.service.impl.service;

import com.epam.event.service.api.service.EventService;
import com.epam.event.service.dto.model.Event;
import com.epam.event.service.dto.model.EventType;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.time.LocalDateTime;
import java.util.List;

import static com.epam.event.service.impl.EventData.getEventPrototype;
import static com.epam.event.service.impl.EventData.getEventsPrototype;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;

@SpringBootTest
class EventServiceImplTest {

    @Autowired
    private EventService service;

    @Test
    void shouldCreateEvent() {
        Event eventPrototype = getEventPrototype();

        long id = service.createEvent(eventPrototype).getId();
        Event event = service.getEvent(id);

        assertThat(event, is(notNullValue()));

        service.deleteEvent(id);
    }

    @Test
    void shouldUpdateEvent() {
        Event eventPrototype = getEventPrototype();

        Event event = service.createEvent(eventPrototype);
        event.setTitle("News");
        long id = event.getId();
        service.updateEvent(event);

        Event updatedEvent = service.getEvent(id);

        assertThat(updatedEvent.getId(), is(id));
        assertThat(updatedEvent.getTitle(), is("News"));

        service.deleteEvent(id);
    }

    @Test
    void shouldGetEvent() {
        LocalDateTime dateTime = LocalDateTime.of(2020, 6, 2, 16, 0);

        Event event = service.getEvent(3L);

        assertThat(event, is(notNullValue()));
        assertThat(event.getId(), is(3L));
        assertThat(event.getTitle(), is("Social Networking"));
        assertThat(event.getPlace(), is("Gorlovskaya 124/3"));
        assertThat(event.getEventType(), is(EventType.WORKSHOP));
        assertThat(event.getDateTime(), is(dateTime));
        assertThat(event.getSpeaker(), is("Siya Mcgrath"));
    }

    @Test
    void shouldDeleteEvent() {
        Event eventPrototype = getEventPrototype();

        long id = service.createEvent(eventPrototype).getId();
        service.deleteEvent(id);
        Event event = service.getEvent(id);

        assertThat(event, is(nullValue()));
    }

    @Test
    void shouldGetAllEvents() {
        List<Event> eventsPrototype = getEventsPrototype();

        List<Event> events = service.getAllEvents();

        assertThat(events, is(eventsPrototype));
    }

    @Test
    void shouldGetAllEventsByTitle() {
        List<Event> events = service.getAllEventsByTitle("Conference");

        assertThat(events, hasSize(2));
    }
}
