package com.epam.event.service.impl.repository;

import com.epam.event.service.dto.model.Event;
import com.epam.event.service.dto.model.EventType;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.dao.DataAccessException;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import static com.epam.event.service.impl.EventData.getEventPrototype;
import static com.epam.event.service.impl.EventData.getEventsPrototype;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.collection.IsCollectionWithSize.hasSize;
import static org.hamcrest.collection.IsEmptyCollection.empty;
import static org.hamcrest.core.IsNull.nullValue;
import static org.junit.jupiter.api.Assertions.assertThrows;

@SpringBootTest
class EventRepositoryTest {

    @Autowired
    private EventRepository repository;

    @Test
    void shouldGetNullEventByNotExistentId() {
        Event event = repository.findById(8L).orElse(null);

        assertThat(event, is(nullValue()));
    }

    @Test
    void shouldGetEventById() {
        LocalDateTime dateTime = LocalDateTime.of(2020, 6, 2, 16, 0);

        Event event = repository.findById(3L).orElse(null);

        assertThat(event, is(notNullValue()));
        assertThat(event.getId(), is(3L));
        assertThat(event.getTitle(), is("Social Networking"));
        assertThat(event.getPlace(), is("Gorlovskaya 124/3"));
        assertThat(event.getEventType(), is(EventType.WORKSHOP));
        assertThat(event.getDateTime(), is(dateTime));
        assertThat(event.getSpeaker(), is("Siya Mcgrath"));
    }

    @Test
    void shouldGetEvents() {
        List<Event> events = new ArrayList<>();
        List<Event> eventsPrototype = getEventsPrototype();

        repository.findAll().forEach(events::add);

        assertThat(events, is(eventsPrototype));
    }

    @Test
    void shouldGetEmptyListWhenTitleNotExist() {
        List<Event> events = repository.getEventsByTitle("News");

        assertThat(events, empty());
    }

    @Test
    void shouldGetEventsByTitle() {
        List<Event> events = repository.getEventsByTitle("Conference");

        assertThat(events, hasSize(2));
        assertThat(events.get(0).getTitle(), is("Conference"));
        assertThat(events.get(1).getTitle(), is("Conference"));
    }

    @Test
    void shouldCreateEvent() {
        Event eventPrototype = getEventPrototype();

        repository.save(eventPrototype);

        long id = eventPrototype.getId();

        Event event = repository.findById(id).orElse(null);

        assertThat(event, is(eventPrototype));

        repository.deleteById(id);
    }

    @Test
    void shouldUpdateEvent() {
        Event eventPrototype = getEventPrototype();

        repository.save(eventPrototype);

        long id = eventPrototype.getId();
        Event event = repository.findById(id).orElse(new Event());
        event.setTitle("New");

        Event updatedEvent = repository.save(event);

        assertThat(updatedEvent.getId(), is(id));
        assertThat(updatedEvent.getTitle(), is("New"));
        assertThat(updatedEvent.getSpeaker(), is(eventPrototype.getSpeaker()));

        repository.deleteById(id);
    }

    @Test
    void shouldThrowExceptionWhenDeleteNotExistentEvent() {
        Event eventPrototype = getEventPrototype();

        repository.save(eventPrototype);

        long id = eventPrototype.getId();

        repository.deleteById(id);

        assertThrows(DataAccessException.class, () -> repository.deleteById(id));
    }

    @Test
    void shouldDeleteEvent() {
        Event eventPrototype = getEventPrototype();

        repository.save(eventPrototype);

        long id = eventPrototype.getId();

        repository.deleteById(id);
        Event event = repository.findById(id).orElse(null);

        assertThat(event, is(nullValue()));
    }
}
