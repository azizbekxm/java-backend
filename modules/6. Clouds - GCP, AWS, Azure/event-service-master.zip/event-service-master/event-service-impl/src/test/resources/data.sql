INSERT INTO events(title, place, event_type, date_time, speaker) VALUES
('Conference', 'Sergeya Esenina 21', 'TECH_TALK', '2020-04-29 14:30:00.000', 'Keenan Cochran'),
('Conference', 'Vysotskogo 17', 'TECH_TALK', '2020-05-05 11:45:00.000', 'Dave Kargen'),
('Social Networking', 'Gorlovskaya 124/3', 'WORKSHOP', '2020-06-02 16:00:00.000', 'Siya Mcgrath');
