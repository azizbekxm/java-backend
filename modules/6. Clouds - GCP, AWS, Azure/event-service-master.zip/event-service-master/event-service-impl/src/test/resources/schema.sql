CREATE TABLE IF NOT EXISTS events(
id bigint AUTO_INCREMENT PRIMARY KEY,
  title      varchar(50) NOT NULL,
  place      varchar(50) NOT NULL,
  event_type varchar(50) NOT NULL,
  date_time  timestamp NOT NULL,
  speaker    varchar(100) NULL);
