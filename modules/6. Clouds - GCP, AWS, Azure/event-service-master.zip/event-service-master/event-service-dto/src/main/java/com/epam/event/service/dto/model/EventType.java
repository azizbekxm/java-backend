package com.epam.event.service.dto.model;

public enum EventType {
    TECH_TALK, WORKSHOP
}
