# TDD, BDD, ATDD Practical Task 

##### 1.	Download Java SE Development Kit 8 according to your OS and processor’s architecture.
##### 2.	Install Java Development Kit according to JDK installation instructions (see also PATH and CLASSPATH).
##### 3.	Download Apache Maven 3.6.0 according to your OS and processor’s architecture.
##### 4.	Install Apache Maven according to installation instructions.
##### 5.	Create maven project with 4 modules:
	*	event-service-api
	*	event-service-dto
	*	event-service-impl
	*	event-service-rest
##### 6.	event-service-dto module should contain Event class with following fields:
	*	id;
	*	title;
	*	place;
	*	speaker;
	*	eventType (enum WORKSHOP, TECH_TALK);
	*	dateTime.
##### 7.	event-service-api module should contain EventService interface with following methods:
	*	getEvents();
	*	getEvent(…);
	*	deleteEvent().
	*	createEvent(…);
	*	updateEvent(…).
##### 8.	event-service-impl module should contain EventServiceImpl which implements EventService interface and responds with list of Events.
    Note: 
    Elaborate JUnit tests for all methods applicable for unit testing using JUnit framework first and them using TDD approach accomplish implementation.
    Feel free to use any database (filesystem, any db, in memory storage).
    Implement Mock class for EventDataProvider using Mockito framework.
##### 9.	event-service-rest module should contain EventServiceController which provides REST API interface according to 2nd or 3rd level of REST API maturity and responds with list of Events.
    Note:
    Implement Application class with @SpringBootApplication annotation and main method.
    Create runnable Spring Boot JAR with dependencies using spring-boot-maven-plugin.
    Implement tests for all methods in EventController class using Cucumber or JBehave frameworks.
