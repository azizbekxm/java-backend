package com.epam.event.service.rest.controller;

import com.epam.event.service.api.service.EventService;
import com.epam.event.service.dto.model.Event;
import com.epam.event.service.dto.model.EventType;
import com.epam.event.service.impl.repository.EventRepository;
import com.epam.event.service.rest.TestUtils;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.util.NestedServletException;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(controllers = EventServiceControllerLevel3.class)
class EventServiceControllerLevel3Test {

    private static final LocalDateTime DATE_TIME =
            LocalDateTime.of(2020, 6, 5, 11, 45);

    @Autowired
    private MockMvc mvc;

    @Autowired
    private EventService service;

    @MockBean
    private EventRepository repository;

    @Test
    void shouldThrowExceptionWhenGetEvents() {
        when(repository.findAll()).thenThrow(new IllegalStateException("Connection lost"));

        Exception exception = assertThrows(NestedServletException.class,
                () -> mvc.perform(get("/l3/event-service/event")));
        assertThat(exception.getMessage(), containsString("Connection lost"));
    }

    @Test
    void shouldGetEvents() throws Exception {
        List<Event> events = getEvents();

        when(repository.findAll()).thenReturn(events);

        mvc.perform(get("/l3/event-service/event")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2)))
                .andExpect(jsonPath("$[0].id", is(1)))
                .andExpect(jsonPath("$[0].dateTime", is("2020-06-05 11:45")))
                .andExpect(jsonPath("$[0].eventType", is("TECH_TALK")))
                .andExpect(jsonPath("$[0].place", is("Ukraine")))
                .andExpect(jsonPath("$[0].speaker", is("Stephan")))
                .andExpect(jsonPath("$[0].title", is("Hub meeting")))
                .andExpect(jsonPath("$[0].links[0].href", containsString("/l3/event-service/event/1")))
                .andExpect(jsonPath("$[1].id", is(2)))
                .andExpect(jsonPath("$[1].dateTime", is("2020-06-05 11:45")))
                .andExpect(jsonPath("$[1].eventType", is("WORKSHOP")))
                .andExpect(jsonPath("$[1].place", is("Ukraine")))
                .andExpect(jsonPath("$[1].speaker", is("Mike")))
                .andExpect(jsonPath("$[1].title", is("Review")))
                .andExpect(jsonPath("$[1].links[0].href", containsString("/l3/event-service/event/2")));
    }

    @Test
    void shouldThrowExceptionWhenUnableToCreateEvent() throws Exception {
        String body = TestUtils.readEntity("createEventRequest.json");
        when(repository.save(any(Event.class))).thenThrow(new IllegalStateException("Db error"));

        Exception exception = assertThrows(NestedServletException.class,
                () -> mvc.perform(post("/l3/event-service/event")
                        .content(body)
                        .contentType(MediaType.APPLICATION_JSON)));
        assertThat(exception.getMessage(), containsString("Db error"));
    }

    @Test
    void shouldCreateEvent() throws Exception {
        String body = TestUtils.readEntity("createEventRequest.json");
        Event event = getEvent(null, "Design ideas", EventType.TECH_TALK, "Julia");
        Event createdEvent = getEvent(1L, "Design ideas", EventType.TECH_TALK, "Julia");
        createdEvent.setId(1L);

        when(repository.save(event)).thenReturn(createdEvent);

        mvc.perform(post("/l3/event-service/event")
                .content(body)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id", is(1)))
                .andExpect(jsonPath("$.links[0].href", containsString("/l3/event-service/event/1")));
        verify(repository).save(event);
    }

    @Test
    void shouldReturnErrorEntityWhenEventByIdToUpdateDoesNotExist() throws Exception {
        String body = TestUtils.readEntity("updateEventRequest.json");
        Event event = getEvent(2L, "title", EventType.TECH_TALK, "Sam");
        when(repository.findById(2L)).thenReturn(Optional.of(event));
        when(repository.save(any(Event.class))).thenReturn(event);

        mvc.perform(put("/l3/event-service/event")
                .content(body)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message", is("Event with id 3 does not exist")));
    }

    @Test
    void shouldUpdateEvent() throws Exception {
        String body = TestUtils.readEntity("updateEventRequest.json");
        Event event = getEvent(3L, "Design ideas", EventType.TECH_TALK, "Julia");
        Event updatedEvent = getEvent(3L, "Design ideas", EventType.TECH_TALK, "Peter");

        when(repository.findById(3L)).thenReturn(Optional.of(event));
        when(repository.save(updatedEvent)).thenReturn(updatedEvent);

        mvc.perform(put("/l3/event-service/event")
                .content(body)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isAccepted())
                .andExpect(jsonPath("$.links[0].href", containsString("/l3/event-service/event/3")));
        verify(repository).findById(3L);
        verify(repository).save(updatedEvent);
    }

    @Test
    void shouldReturnNotFoundStatusWhenEventByIdDoesNotExist() throws Exception {
        Event event = getEvent();

        when(repository.findById(3L)).thenReturn(Optional.of(event));

        mvc.perform(get("/l3/event-service/event/2")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());
    }

    @Test
    void shouldThrowExceptionWhenGetEventById() {
        Event event = getEvent();

        when(repository.findById(2L)).thenReturn(Optional.of(event));
        when(repository.findById(3L)).thenThrow(new IllegalStateException("Service error"));

        Exception exception = assertThrows(NestedServletException.class,
                () -> mvc.perform(get("/l3/event-service/event/3")
                        .contentType(MediaType.APPLICATION_JSON)));
        assertThat(exception.getMessage(), containsString("Service error"));
    }

    @Test
    void shouldGetEvent() throws Exception {
        Event event = getEvent();

        when(repository.findById(1L)).thenReturn(Optional.of(event));

        mvc.perform(get("/l3/event-service/event/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id", is(1)))
                .andExpect(jsonPath("$.dateTime", is("2020-06-05 11:45")))
                .andExpect(jsonPath("$.eventType", is("TECH_TALK")))
                .andExpect(jsonPath("$.place", is("Ukraine")))
                .andExpect(jsonPath("$.speaker", is("Stephan")))
                .andExpect(jsonPath("$.title", is("Hub meeting")))
                .andExpect(jsonPath("$.links[0].href", containsString("/l3/event-service/event/1")));
    }

    @Test
    void shouldReturnErrorEntityWhenEventAlreadyDeleted() throws Exception {
        doThrow(new IllegalStateException("Delete already deleted")).when(repository).deleteById(3L);

        mvc.perform(delete("/l3/event-service/event/3")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isInternalServerError())
                .andExpect(jsonPath("$.message", is("Internal server error")));
    }

    @Test
    void shouldDeleteEvent() throws Exception {
        mvc.perform(delete("/l3/event-service/event/3")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());
        verify(repository).deleteById(3L);
    }

    @Test
    void shouldReturnNotFoundStatusWhenEventsByTitleNotFound() throws Exception {
        Event event = getEvent(1L, "Mass event", EventType.WORKSHOP, "Luis");

        when(repository.getEventsByTitle("Mass event")).thenReturn(Collections.singletonList(event));

        mvc.perform(get("/l3/event-service/event/title/Blog")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());
        verify(repository).getEventsByTitle("Blog");
    }

    @Test
    void shouldThrowExceptionWhenGetEventByTitle() {
        when(repository.getEventsByTitle("Mass event")).thenThrow(new IllegalStateException("Unsupported operation"));

        Exception exception = assertThrows(NestedServletException.class,
                () -> mvc.perform(get("/l3/event-service/event/title/Mass event")
                        .contentType(MediaType.APPLICATION_JSON)));
        assertThat(exception.getMessage(), containsString("Unsupported operation"));
    }

    @Test
    void shouldGetEventsByTitle() throws Exception {
        Event event = getEvent(2L, "Challenge", EventType.WORKSHOP, "Roger");

        when(repository.getEventsByTitle("Mass event")).thenReturn(Collections.singletonList(event));

        mvc.perform(get("/l3/event-service/event/title/Mass event")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(1)))
                .andExpect(jsonPath("$[0].id", is(2)))
                .andExpect(jsonPath("$[0].dateTime", is("2020-06-05 11:45")))
                .andExpect(jsonPath("$[0].eventType", is("WORKSHOP")))
                .andExpect(jsonPath("$[0].place", is("Ukraine")))
                .andExpect(jsonPath("$[0].speaker", is("Roger")))
                .andExpect(jsonPath("$[0].title", is("Challenge")))
                .andExpect(jsonPath("$[0].links[0].href", containsString("/l3/event-service/event/2")));
    }

    private static List<Event> getEvents() {
        Event event = getEvent();
        Event event2 = getEvent(2L, "Review", EventType.WORKSHOP, "Mike");
        return Arrays.asList(event, event2);
    }

    private static Event getEvent() {
        return getEvent(1L, "Hub meeting", EventType.TECH_TALK, "Stephan");
    }

    private static Event getEvent(Long id, String title, EventType eventType, String speaker) {
        Event event = new Event();
        event.setId(id);
        event.setTitle(title);
        event.setEventType(eventType);
        event.setSpeaker(speaker);
        event.setPlace("Ukraine");
        event.setDateTime(DATE_TIME);
        return event;
    }
}
