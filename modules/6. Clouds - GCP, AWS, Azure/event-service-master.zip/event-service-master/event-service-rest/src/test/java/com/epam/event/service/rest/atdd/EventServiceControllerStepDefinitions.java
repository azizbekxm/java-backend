package com.epam.event.service.rest.atdd;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.everyItem;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.isIn;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.nullValue;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import com.epam.event.service.rest.dto.CreateEventExtendedResponse;
import com.epam.event.service.rest.dto.CreateEventResponse;
import com.epam.event.service.rest.dto.ErrorResponse;
import com.epam.event.service.rest.dto.EventExtendedResponse;
import com.epam.event.service.rest.dto.EventRequest;
import com.epam.event.service.rest.dto.EventResponse;
import com.epam.event.service.rest.dto.UpdateEventRequest;
import com.epam.event.service.rest.dto.UpdateEventResponse;
import io.cucumber.java.After;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.hateoas.Link;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

@SuppressWarnings({"unchecked", "ConstantConditions"})
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class EventServiceControllerStepDefinitions {

    private static final String L2_BASE_PATH = "l2/event-service/event/";
    private static final String L3_BASE_PATH = "l3/event-service/event/";

    @LocalServerPort
    private int port;

    @Autowired
    private RestTemplate template;
    private ResponseEntity lastResponse;
    private List<Long> createdIds = new ArrayList<>();

    @Given("^Event with title '(.+)', place '(.+)', eventType '(.+)', dateTime '(.+)', speaker '(.+)'$")
    public void setupEvent(String title, String place, String eventType, String dateTime, String speaker) {
        EventRequest requestBody = new EventRequest(null, dateTime, eventType, place, speaker, title);
        initEvent(requestBody, L2_BASE_PATH);
    }

    @Given("^extended Event with title '(.+)', place '(.+)', eventType '(.+)', dateTime '(.+)', speaker '(.+)'$")
    public void setupExtendedEvent(String title, String place, String eventType, String dateTime, String speaker) {
        EventRequest requestBody = new EventRequest(null, dateTime, eventType, place, speaker, title);
        initEvent(requestBody, L3_BASE_PATH);
    }

    @Given("Events:")
    public void events(List<EventRequest> events) {
        events.forEach(event -> initEvent(event, L2_BASE_PATH));
    }

    @Given("extended Events:")
    public void extendedEvents(List<EventRequest> events) {
        events.forEach(event -> initEvent(event, L3_BASE_PATH));
    }

    @When("get Events")
    public void getAllEvents() {
        lastResponse = template.exchange(getUrl(L2_BASE_PATH), HttpMethod.GET, null,
                new ParameterizedTypeReference<List<EventResponse>>() {
                });
    }

    @When("get extended Events")
    public void getExtendedEvents() {
        lastResponse = template.exchange(getUrl(L3_BASE_PATH), HttpMethod.GET, null,
                new ParameterizedTypeReference<List<EventExtendedResponse>>() {
                });
    }

    @When("^create Event with title '(.+)', place '(.+)', eventType '(.+)', dateTime '(.+)', speaker (.+)$")
    public void createEvent(String title, String place, String eventType, String dateTime, String speaker) {
        EventRequest requestBody = new EventRequest(null, dateTime, eventType, place, speaker, title);
        createEvent(requestBody, L2_BASE_PATH, CreateEventResponse.class);
    }

    @When("^create extended Event with title '(.+)', place '(.+)', eventType '(.+)', dateTime '(.+)', speaker (.+)$")
    public void createExtendedEvent(String title, String place, String eventType, String dateTime, String speaker) {
        EventRequest requestBody = new EventRequest(null, dateTime, eventType, place, speaker, title);
        createEvent(requestBody, L3_BASE_PATH, CreateEventExtendedResponse.class);
    }

    @When("^update Event with non existing id (\\d+), "
            + "title '(.+)', place '(.+)', eventType '(.+)', dateTime '(.+)', speaker '(.+)'$")
    public void updateNotExistentEvent(Long id, String title, String place, String eventType, String dateTime,
            String speaker) {
        UpdateEventRequest requestBody = new UpdateEventRequest(id, dateTime, eventType, place, speaker, title);
        updateNotExistentEvent(requestBody, L2_BASE_PATH);
    }

    @When("^update extended Event with non existing id (\\d+), "
            + "title '(.+)', place '(.+)', eventType '(.+)', dateTime '(.+)', speaker '(.+)'$")
    public void updateNotExistentExtendedEvent(Long id, String title, String place, String eventType, String dateTime,
            String speaker) {
        UpdateEventRequest requestBody = new UpdateEventRequest(id, dateTime, eventType, place, speaker, title);
        updateNotExistentEvent(requestBody, L3_BASE_PATH);
    }

    @When("^update Event with title '(.+)', place '(.+)', eventType '(.+)', dateTime '(.+)', speaker '(.+)'$")
    public void updateEvent(String title, String place, String eventType, String dateTime, String speaker) {
        Long id = findFirstId();
        UpdateEventRequest requestBody = new UpdateEventRequest(id, dateTime, eventType, place, speaker, title);
        updateEvent(requestBody, L2_BASE_PATH);
    }

    @When("^update extended Event with title '(.+)', place '(.+)', eventType '(.+)', dateTime '(.+)', speaker '(.+)'$")
    public void updateExtendedEvent(String title, String place, String eventType, String dateTime, String speaker) {
        Long id = findFirstId();
        UpdateEventRequest requestBody = new UpdateEventRequest(id, dateTime, eventType, place, speaker, title);
        updateEvent(requestBody, L3_BASE_PATH);
    }

    @When("^get event by id (\\d+)$")
    public void getEventById(Long id) {
        lastResponse = template.exchange(getUrl(L2_BASE_PATH + id), HttpMethod.GET, null,
                EventResponse.class);
    }

    @When("^get extended event by id (\\d+)$")
    public void getExtendedEventById(Long id) {
        lastResponse = template.exchange(getUrl(L3_BASE_PATH + id), HttpMethod.GET, null,
                EventExtendedResponse.class);
    }

    @When("get event by id")
    public void getEventById() {
        Long id = findFirstId();
        lastResponse = template.exchange(getUrl(L2_BASE_PATH + id), HttpMethod.GET, null,
                EventResponse.class);
    }

    @When("get extended event by id")
    public void getExtendedEventById() {
        Long id = findFirstId();
        lastResponse = template.exchange(getUrl(L3_BASE_PATH + id), HttpMethod.GET, null,
                EventExtendedResponse.class);
    }

    @When("delete event by id")
    public void deleteEventById() {
        Long id = findFirstId();
        lastResponse = template.exchange(getUrl(L2_BASE_PATH + id), HttpMethod.DELETE, null,
                Void.class);
    }

    @When("delete extended event by id")
    public void deleteExtendedEventById() {
        Long id = findFirstId();
        lastResponse = template.exchange(getUrl(L3_BASE_PATH + id), HttpMethod.DELETE, null,
                Void.class);
    }

    @When("^get events by title '(.+)'$")
    public void getEventsByTitle(String title) {
        lastResponse = template.exchange(getUrl(L2_BASE_PATH + "title/" + title), HttpMethod.GET, null,
                new ParameterizedTypeReference<List<EventResponse>>() {
                });
    }

    @When("^get extended events by title '(.+)'$")
    public void getExtendedEventsByTitle(String title) {
        lastResponse = template.exchange(getUrl(L3_BASE_PATH + "title/" + title), HttpMethod.GET, null,
                new ParameterizedTypeReference<List<EventExtendedResponse>>() {
                });
    }

    @Then("get Events:")
    public void allEventsResult(List<EventResponse> events) {
        List<EventResponse> responses = (List<EventResponse>) lastResponse.getBody();

        for (int i = 0; i < events.size(); i++) {
            Long id = createdIds.get(i);
            EventResponse event = events.get(i);
            event.setId(id);
        }

        assertThat(events, everyItem(isIn(responses)));
    }

    @Then("get extended Events:")
    public void extendedEventsResult(List<EventExtendedResponse> events) {
        List<EventExtendedResponse> responses = (List<EventExtendedResponse>) lastResponse.getBody();

        for (int i = 0; i < events.size(); i++) {
            Long id = createdIds.get(i);
            EventExtendedResponse event = events.get(i);
            event.setId(id);
            event.add(buildLink(id));
        }

        assertThat(events, everyItem(isIn(responses)));
    }

    @Then("event created with non empty id")
    public void createEventResult() {
        CreateEventResponse response = (CreateEventResponse) lastResponse.getBody();
        Long id = response.getId();
        createdIds.add(id);

        assertThat(id, is(notNullValue()));
    }

    @Then("extended event created with non empty id")
    public void createExtendedEventResult() {
        CreateEventExtendedResponse response = (CreateEventExtendedResponse) lastResponse.getBody();
        Long id = response.getId();
        createdIds.add(id);

        assertThat(id, is(notNullValue()));
        assertThat(response.getLinks().contains(buildLink(id)), is(true));
    }

    @Then("get updated extended Event")
    public void extendedUpdateEventResult() {
        Long id = findFirstId();
        UpdateEventResponse response = (UpdateEventResponse) lastResponse.getBody();

        assertThat(response.getLinks().contains(buildLink(id)), is(true));
    }

    @Then("^get event with id, title '(.+)', place '(.+)', eventType '(.+)', dateTime '(.+)', speaker '(.+)'$")
    public void eventByIdResult(String title, String place, String eventType, String dateTime, String speaker) {
        Long id = findFirstId();
        EventResponse response = new EventResponse(id, dateTime, eventType, place, speaker, title);
        EventResponse responseBody = (EventResponse) lastResponse.getBody();

        assertThat(responseBody, is(response));
    }

    @Then("^get extended event with id, title '(.+)', place '(.+)', eventType '(.+)', dateTime '(.+)', speaker '(.+)'$")
    public void extendedEventByIdResult(String title, String place, String eventType, String dateTime, String speaker) {
        Long id = findFirstId();
        EventExtendedResponse responseBody = (EventExtendedResponse) lastResponse.getBody();
        EventExtendedResponse response = new EventExtendedResponse(id, dateTime, eventType, place, speaker, title);
        response.add(buildLink(id));

        assertThat(responseBody, is(response));
    }

    @Then("don't have event with deleted id")
    public void deleteEventResult() {
        Object responseBody = deleteEvent(L2_BASE_PATH);

        assertThat(responseBody, is(nullValue()));
    }

    @Then("don't have extended event with deleted id")
    public void deleteExtendedEventResult() {
        Object responseBody = deleteEvent(L3_BASE_PATH);

        assertThat(responseBody, is(nullValue()));
    }

    @Then("^get error response with message '(.+)'$")
    public void errorResponse(String message) {
        ErrorResponse body = (ErrorResponse) lastResponse.getBody();

        assertThat(body.getMessage(), is(message));
    }

    @Then("get empty body")
    public void emptyBody() {
        Object body = lastResponse.getBody();

        assertThat(body, is(nullValue()));
    }

    @Then("Status {int}")
    public void statusCode(int statusCode) {
        assertThat(lastResponse.getStatusCodeValue(), is(statusCode));
    }

    @Then("Content-Type {}")
    public void contentType(String contentType) {
        MediaType contentTypeResult = lastResponse.getHeaders().getContentType();

        assertThat(contentTypeResult, is(MediaType.valueOf(contentType)));
    }

    @After
    public void after() {
        for (Long id : createdIds) {
            template.exchange(getUrl(L2_BASE_PATH + id), HttpMethod.DELETE, null, Void.class);
        }
        createdIds.clear();
    }

    private void initEvent(EventRequest requestBody, String basePath) {
        RequestEntity<EventRequest> requestEntity =
                new RequestEntity<>(requestBody, HttpMethod.POST, URI.create(getUrl(basePath)));
        ResponseEntity<CreateEventResponse> response = template.exchange(requestEntity, CreateEventResponse.class);
        CreateEventResponse responseBody = response.getBody();
        createdIds.add(responseBody.getId());
    }

    private void createEvent(EventRequest requestBody, String basePath, Class clazz) {
        requestEvent(requestBody, HttpMethod.POST, basePath, clazz);
    }

    private void updateEvent(UpdateEventRequest requestBody, String basePath) {
        requestEvent(requestBody, HttpMethod.PUT, basePath, UpdateEventResponse.class);
    }

    private void updateNotExistentEvent(UpdateEventRequest requestBody, String basePath) {
        requestEvent(requestBody, HttpMethod.PUT, basePath, ErrorResponse.class);
    }

    private Object deleteEvent(String basePath) {
        Long id = findFirstId();
        ResponseEntity response = template.exchange(getUrl(basePath + id), HttpMethod.GET, null,
                EventResponse.class);
        Object responseBody = response.getBody();
        createdIds.clear();
        return responseBody;
    }

    private <T> void requestEvent(T requestBody, HttpMethod method, String basePath, Class clazz) {
        RequestEntity<T> requestEntity = new RequestEntity<>(requestBody, method, URI.create(getUrl(basePath)));
        lastResponse = template.exchange(requestEntity, clazz);
    }

    private Long findFirstId() {
        return createdIds.stream()
                .findFirst()
                .orElseThrow(() -> new IllegalStateException("Event does not exist"));
    }

    private String getUrl(String path) {
        return String.format("http://localhost:%d/%s", port, path);
    }

    private Link buildLink(Long id) {
        String link = String.format("http://localhost:%d/%s%d", port, L3_BASE_PATH, id);
        return new Link(link);
    }
}
