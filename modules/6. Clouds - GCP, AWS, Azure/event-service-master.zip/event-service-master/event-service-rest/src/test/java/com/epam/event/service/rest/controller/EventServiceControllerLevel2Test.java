package com.epam.event.service.rest.controller;

import com.epam.event.service.api.service.EventService;
import com.epam.event.service.dto.model.Event;
import com.epam.event.service.dto.model.EventType;
import com.epam.event.service.impl.repository.EventRepository;
import com.epam.event.service.rest.TestUtils;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.util.NestedServletException;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(controllers = EventServiceControllerLevel2.class)
class EventServiceControllerLevel2Test {

    private static final LocalDateTime DATE_TIME =
            LocalDateTime.of(2020, 6, 5, 11, 45);

    @Autowired
    private MockMvc mvc;

    @Autowired
    private EventService service;

    @MockBean
    private EventRepository repository;

    @Test
    void shouldThrowExceptionWhenGetEvents() {
        when(repository.findAll()).thenThrow(new IllegalStateException("Events are not available"));

        Exception exception = assertThrows(NestedServletException.class,
                () -> mvc.perform(get("/l2/event-service/event")));
        assertThat(exception.getMessage(), containsString("Events are not available"));
    }

    @Test
    void shouldGetEvents() throws Exception {
        List<Event> events = getEvents();

        when(repository.findAll()).thenReturn(events);

        mvc.perform(get("/l2/event-service/event")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2)))
                .andExpect(jsonPath("$[0].id", is(3)))
                .andExpect(jsonPath("$[0].dateTime", is("2020-06-05 11:45")))
                .andExpect(jsonPath("$[0].eventType", is("TECH_TALK")))
                .andExpect(jsonPath("$[0].place", is("Ukraine")))
                .andExpect(jsonPath("$[0].speaker", is("Julia")))
                .andExpect(jsonPath("$[0].title", is("Design ideas")))
                .andExpect(jsonPath("$[1].id", is(5)))
                .andExpect(jsonPath("$[1].dateTime", is("2020-06-05 11:45")))
                .andExpect(jsonPath("$[1].eventType", is("WORKSHOP")))
                .andExpect(jsonPath("$[1].place", is("Ukraine")))
                .andExpect(jsonPath("$[1].speaker", is("Ben")))
                .andExpect(jsonPath("$[1].title", is("Conference")));
    }

    @Test
    void shouldThrowExceptionWhenUnableToCreateEvent() throws Exception {
        String body = TestUtils.readEntity("createEventRequest.json");
        when(repository.save(any(Event.class))).thenThrow(new IllegalStateException("Unable to create event"));

        Exception exception = assertThrows(NestedServletException.class,
                () -> mvc.perform(post("/l2/event-service/event")
                        .content(body)
                        .contentType(MediaType.APPLICATION_JSON)));
        assertThat(exception.getMessage(), containsString("Unable to create event"));
    }

    @Test
    void shouldCreateEvent() throws Exception {
        String body = TestUtils.readEntity("createEventRequest.json");
        Event event = getEvent();
        event.setId(null);
        Event createdEvent = getEvent();
        createdEvent.setId(1L);

        when(repository.save(event)).thenReturn(createdEvent);

        mvc.perform(post("/l2/event-service/event")
                .content(body)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id", is(1)));
        verify(repository).save(event);
    }

    @Test
    void shouldReturnErrorEntityWhenEventByIdToUpdateDoesNotExist() throws Exception {
        String body = TestUtils.readEntity("updateEventRequest.json");
        Event event = getEvent(2L, "title", EventType.TECH_TALK, "Sam");
        when(repository.findById(2L)).thenReturn(Optional.of(event));
        when(repository.save(any(Event.class))).thenReturn(event);

        mvc.perform(put("/l2/event-service/event")
                .content(body)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message", is("Event with id 3 does not exist")));
    }

    @Test
    void shouldUpdateEvent() throws Exception {
        String body = TestUtils.readEntity("updateEventRequest.json");
        Event event = getEvent();
        Event updatedEvent = getEvent();
        updatedEvent.setSpeaker("Peter");

        when(repository.findById(3L)).thenReturn(Optional.of(event));
        when(repository.save(updatedEvent)).thenReturn(updatedEvent);

        mvc.perform(put("/l2/event-service/event")
                .content(body)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());
        verify(repository).findById(3L);
        verify(repository).save(updatedEvent);
    }

    @Test
    void shouldReturnNotFoundStatusWhenEventByIdDoesNotExist() throws Exception {
        Event event = getEvent();

        when(repository.findById(3L)).thenReturn(Optional.of(event));

        mvc.perform(get("/l2/event-service/event/2")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());
    }

    @Test
    void shouldThrowExceptionWhenGetEventById() {
        Event event = getEvent();

        when(repository.findById(2L)).thenReturn(Optional.of(event));
        when(repository.findById(3L)).thenThrow(new IllegalStateException("Service unavailable"));

        Exception exception = assertThrows(NestedServletException.class,
                () -> mvc.perform(get("/l2/event-service/event/3")
                        .contentType(MediaType.APPLICATION_JSON)));
        assertThat(exception.getMessage(), containsString("Service unavailable"));
    }

    @Test
    void shouldGetEvent() throws Exception {
        Event event = getEvent();

        when(repository.findById(3L)).thenReturn(Optional.of(event));

        mvc.perform(get("/l2/event-service/event/3")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id", is(3)))
                .andExpect(jsonPath("$.dateTime", is("2020-06-05 11:45")))
                .andExpect(jsonPath("$.eventType", is("TECH_TALK")))
                .andExpect(jsonPath("$.place", is("Ukraine")))
                .andExpect(jsonPath("$.speaker", is("Julia")))
                .andExpect(jsonPath("$.title", is("Design ideas")));
    }

    @Test
    void shouldReturnErrorEntityWhenEventAlreadyDeleted() throws Exception {
        doThrow(new IllegalStateException("Delete already deleted")).when(repository).deleteById(3L);

        mvc.perform(delete("/l2/event-service/event/3")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isInternalServerError())
                .andExpect(jsonPath("$.message", is("Internal server error")));
    }

    @Test
    void shouldDeleteEvent() throws Exception {
        mvc.perform(delete("/l2/event-service/event/3")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());
        verify(repository).deleteById(3L);
    }

    @Test
    void shouldReturnNotFoundStatusWhenEventsByTitleNotFound() throws Exception {
        Event event = getEvent(1L, "Mass event", EventType.WORKSHOP, "Luis");

        when(repository.getEventsByTitle("Mass event")).thenReturn(Collections.singletonList(event));

        mvc.perform(get("/l2/event-service/event/title/WebHub")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());
        verify(repository).getEventsByTitle("WebHub");
    }

    @Test
    void shouldThrowExceptionWhenGetEventByTitle() {
        when(repository.getEventsByTitle("Mass event")).thenThrow(new IllegalStateException("Connection error"));

        Exception exception = assertThrows(NestedServletException.class,
                () -> mvc.perform(get("/l2/event-service/event/title/Mass event")
                        .contentType(MediaType.APPLICATION_JSON)));
        assertThat(exception.getMessage(), containsString("Connection error"));
    }

    @Test
    void shouldGetEventsByTitle() throws Exception {
        Event event = getEvent(1L, "Mass event", EventType.WORKSHOP, "Luis");

        when(repository.getEventsByTitle("Mass event")).thenReturn(Collections.singletonList(event));

        mvc.perform(get("/l2/event-service/event/title/Mass event")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(1)))
                .andExpect(jsonPath("$[0].id", is(1)))
                .andExpect(jsonPath("$[0].dateTime", is("2020-06-05 11:45")))
                .andExpect(jsonPath("$[0].eventType", is("WORKSHOP")))
                .andExpect(jsonPath("$[0].place", is("Ukraine")))
                .andExpect(jsonPath("$[0].speaker", is("Luis")))
                .andExpect(jsonPath("$[0].title", is("Mass event")));
    }

    private static List<Event> getEvents() {
        Event event = getEvent();
        Event event2 = getEvent(5L, "Conference", EventType.WORKSHOP, "Ben");
        return Arrays.asList(event, event2);
    }

    private static Event getEvent() {
        return getEvent(3L, "Design ideas", EventType.TECH_TALK, "Julia");
    }

    private static Event getEvent(Long id, String title, EventType eventType, String speaker) {
        Event event = new Event();
        event.setId(id);
        event.setTitle(title);
        event.setEventType(eventType);
        event.setSpeaker(speaker);
        event.setPlace("Ukraine");
        event.setDateTime(DATE_TIME);
        return event;
    }
}
