package com.epam.event.service.rest.mapper;

import com.epam.event.service.dto.model.Event;
import com.epam.event.service.dto.model.EventType;
import com.epam.event.service.rest.dto.EventExtendedResponse;
import com.epam.event.service.rest.dto.EventRequest;
import com.epam.event.service.rest.dto.EventResponse;
import com.epam.event.service.rest.dto.UpdateEventRequest;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.hasItems;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertNull;

class EventMapperTest {

    private static final LocalDateTime DATE_TIME =
            LocalDateTime.of(2020, 6, 5, 11, 45);

    private EventMapper mapper = new EventMapper();

    @Test
    void shouldMapNullObjects() {
        assertNull(mapper.toEvent((EventRequest) null));
        assertNull(mapper.toEvent((UpdateEventRequest) null));
        assertNull(mapper.toEventResponse((Event) null));
        assertNull(mapper.toEventResponse((List<Event>) null));
        assertNull(mapper.toEventExtendedResponse((Event) null));
        assertNull(mapper.toEventExtendedResponse((List<Event>) null));
    }

    @Test
    void shouldMapFromEventRequestToEvent() {
        EventRequest request = getEventRequest();
        LocalDateTime dateTime = LocalDateTime.of(2020, 5, 5, 11, 45);

        Event event = mapper.toEvent(request);

        assertThat(event.getId(), is(5L));
        assertThat(event.getTitle(), is("Title"));
        assertThat(event.getSpeaker(), is("John"));
        assertThat(event.getEventType(), is(EventType.TECH_TALK));
        assertThat(event.getPlace(), is("Ukraine"));
        assertThat(event.getDateTime(), is(dateTime));
    }

    @Test
    void shouldMapFromUpdateEventRequestToEvent() {
        UpdateEventRequest request = getUpdateEventRequest();

        Event event = mapper.toEvent(request);

        assertThat(event.getId(), is(5L));
        assertThat(event.getTitle(), is("Title"));
        assertThat(event.getSpeaker(), is("John"));
        assertThat(event.getEventType(), is(EventType.TECH_TALK));
        assertThat(event.getPlace(), is("Ukraine"));
        assertThat(event.getDateTime(), is(DATE_TIME));
    }

    @Test
    void shouldMapFromEventsToEventResponses() {
        List<Event> events = getEvents();

        List<EventResponse> responses = mapper.toEventResponse(events);

        EventResponse response = new EventResponse();
        response.setId(5L);
        response.setTitle("Title");
        response.setEventType("TECH_TALK");
        response.setSpeaker("John");
        response.setPlace("Ukraine");
        response.setDateTime("2020-06-05 11:45");
        EventResponse response2 = new EventResponse();
        response2.setId(3L);
        response2.setTitle("Nugis");
        response2.setEventType("WORKSHOP");
        response2.setSpeaker("Bavia");
        response2.setPlace("Ukraine");
        response2.setDateTime("2020-06-05 11:45");

        assertThat(responses, hasSize(2));
        assertThat(responses, hasItems(response, response2));
    }

    @Test
    void shouldMapFromEventToEventResponse() {
        Event event = getEvent();

        EventResponse response = mapper.toEventResponse(event);

        assertThat(response.getId(), is(5L));
        assertThat(response.getTitle(), is("Title"));
        assertThat(response.getSpeaker(), is("John"));
        assertThat(response.getEventType(), is("TECH_TALK"));
        assertThat(response.getPlace(), is("Ukraine"));
        assertThat(response.getDateTime(), is("2020-06-05 11:45"));
    }

    @Test
    void shouldMapFromEventsToEventExtendedResponses() {
        List<Event> events = getEvents();

        List<EventExtendedResponse> responses = mapper.toEventExtendedResponse(events);

        EventExtendedResponse response = new EventExtendedResponse();
        response.setId(5L);
        response.setTitle("Title");
        response.setEventType("TECH_TALK");
        response.setSpeaker("John");
        response.setPlace("Ukraine");
        response.setDateTime("2020-06-05 11:45");
        EventExtendedResponse response2 = new EventExtendedResponse();
        response2.setId(3L);
        response2.setTitle("Nugis");
        response2.setEventType("WORKSHOP");
        response2.setSpeaker("Bavia");
        response2.setPlace("Ukraine");
        response2.setDateTime("2020-06-05 11:45");

        assertThat(responses, hasSize(2));
        assertThat(responses, hasItems(response, response2));
    }

    @Test
    void shouldMapFromEventToEventExtendedResponse() {
        Event event = getEvent();

        EventExtendedResponse response = mapper.toEventExtendedResponse(event);

        assertThat(response.getId(), is(5L));
        assertThat(response.getTitle(), is("Title"));
        assertThat(response.getSpeaker(), is("John"));
        assertThat(response.getEventType(), is("TECH_TALK"));
        assertThat(response.getPlace(), is("Ukraine"));
        assertThat(response.getDateTime(), is("2020-06-05 11:45"));
    }

    private static EventRequest getEventRequest() {
        EventRequest request = new EventRequest();
        request.setId(5L);
        request.setTitle("Title");
        request.setEventType("TECH_TALK");
        request.setSpeaker("John");
        request.setPlace("Ukraine");
        request.setDateTime("2020-05-05T11:45");
        return request;
    }

    private static UpdateEventRequest getUpdateEventRequest() {
        UpdateEventRequest request = new UpdateEventRequest();
        request.setId(5L);
        request.setTitle("Title");
        request.setPlace("Ukraine");
        request.setSpeaker("John");
        request.setEventType("TECH_TALK");
        request.setDateTime("2020-06-05T11:45");
        return request;
    }

    private static List<Event> getEvents() {
        Event event = getEvent();
        Event event2 = getEvent(3L, "Nugis", EventType.WORKSHOP, "Bavia");
        return Arrays.asList(event, event2);
    }

    private static Event getEvent() {
        return getEvent(5L, "Title", EventType.TECH_TALK, "John");
    }

    private static Event getEvent(long id, String title, EventType eventType, String speaker) {
        Event event = new Event();
        event.setId(id);
        event.setTitle(title);
        event.setEventType(eventType);
        event.setSpeaker(speaker);
        event.setPlace("Ukraine");
        event.setDateTime(DATE_TIME);
        return event;
    }
}
