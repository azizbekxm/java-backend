package com.epam.event.service.rest.atdd;

import java.util.Collections;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.ExtractingResponseErrorHandler;
import org.springframework.web.client.RestTemplate;

@Configuration
public class CucumberSpringConfiguration {

    @Bean
    public RestTemplate template() {
        RestTemplate template = new RestTemplate(new SimpleClientHttpRequestFactory());
        ExtractingResponseErrorHandler errorHandler = new ExtractingResponseErrorHandler();

        errorHandler.setSeriesMapping(Collections.singletonMap(HttpStatus.Series.CLIENT_ERROR, null));
        template.setErrorHandler(errorHandler);
        return template;
    }
}
