package com.epam.event.service.rest.atdd;

import com.epam.event.service.rest.dto.EventExtendedResponse;
import com.epam.event.service.rest.dto.EventRequest;
import com.epam.event.service.rest.dto.EventResponse;
import io.cucumber.java.DataTableType;

import java.util.Map;

public class EventDataType {

    @DataTableType
    public EventRequest eventRequest(Map<String, String> entry) {
        EventRequest request = new EventRequest();
        request.setTitle(entry.get("title"));
        request.setPlace(entry.get("place"));
        request.setEventType(entry.get("eventType"));
        request.setDateTime(entry.get("dateTime"));
        request.setSpeaker(entry.get("speaker"));
        return request;
    }

    @DataTableType
    public EventResponse eventResponse(Map<String, String> entry) {
        EventResponse response = new EventResponse();
        response.setTitle(entry.get("title"));
        response.setPlace(entry.get("place"));
        response.setEventType(entry.get("eventType"));
        response.setDateTime(entry.get("dateTime"));
        response.setSpeaker(entry.get("speaker"));
        return response;
    }

    @DataTableType
    public EventExtendedResponse eventExtendedResponse(Map<String, String> entry) {
        EventExtendedResponse response = new EventExtendedResponse();
        response.setTitle(entry.get("title"));
        response.setPlace(entry.get("place"));
        response.setEventType(entry.get("eventType"));
        response.setDateTime(entry.get("dateTime"));
        response.setSpeaker(entry.get("speaker"));
        return response;
    }
}
