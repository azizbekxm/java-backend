package com.epam.event.service.rest.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.springframework.hateoas.RepresentationModel;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class UpdateEventResponse extends RepresentationModel {
}
