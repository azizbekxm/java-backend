package com.epam.event.service.rest.controller;

import com.epam.event.service.api.service.EventService;
import com.epam.event.service.dto.model.Event;
import com.epam.event.service.rest.dto.CreateEventExtendedResponse;
import com.epam.event.service.rest.dto.ErrorResponse;
import com.epam.event.service.rest.dto.EventExtendedResponse;
import com.epam.event.service.rest.dto.EventRequest;
import com.epam.event.service.rest.dto.UpdateEventRequest;
import com.epam.event.service.rest.dto.UpdateEventResponse;
import com.epam.event.service.rest.mapper.EventMapper;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.hateoas.Link;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.util.List;

import static java.lang.String.format;

@RestController
@RequestMapping(value = "/l3/event-service")
public class EventServiceControllerLevel3 {

    private static final String ID = "/{id}";

    private final EventService eventService;
    private final EventMapper mapper;

    public EventServiceControllerLevel3(EventService eventService, EventMapper mapper) {
        this.eventService = eventService;
        this.mapper = mapper;
    }

    @ApiResponses({
            @ApiResponse(code = 200, message = "Success", response = EventExtendedResponse[].class),
            @ApiResponse(code = 500, message = "Internal server error")
    })
    @GetMapping(value = "/event", produces = "application/json")
    public ResponseEntity<List<EventExtendedResponse>> getEvents() {
        List<Event> events = eventService.getAllEvents();
        List<EventExtendedResponse> response = mapper.toEventExtendedResponse(events);
        for (EventExtendedResponse eventResponse : response) {
            String uri = ServletUriComponentsBuilder.fromCurrentRequest().path(ID)
                    .buildAndExpand(eventResponse.getId()).toUriString();
            eventResponse.add(new Link(uri));
        }

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @ApiResponses({
            @ApiResponse(code = 200, message = "Event created", response = CreateEventExtendedResponse.class),
            @ApiResponse(code = 500, message = "Internal server error")
    })
    @PostMapping(value = "/event", produces = "application/json")
    public ResponseEntity<CreateEventExtendedResponse> createEvent(@RequestBody EventRequest request) {
        Event event = mapper.toEvent(request);
        Event eventCreated = eventService.createEvent(event);

        CreateEventExtendedResponse response = new CreateEventExtendedResponse(eventCreated.getId());
        String uri = ServletUriComponentsBuilder.fromCurrentRequest().path(ID)
                .buildAndExpand(response.getId()).toUriString();
        response.add(new Link(uri));

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @ApiResponses({
            @ApiResponse(code = 202, message = "Event updated"),
            @ApiResponse(code = 400, message = "Bad request", response = ErrorResponse.class),
            @ApiResponse(code = 500, message = "Internal server error")
    })
    @PutMapping(value = "/event", produces = "application/json")
    @ResponseStatus(value = HttpStatus.ACCEPTED)
    public ResponseEntity updateEvent(@RequestBody UpdateEventRequest request) {
        Event event = mapper.toEvent(request);
        Event updateEvent = eventService.updateEvent(event);

        if (updateEvent == null) {
            return new ResponseEntity<>(new ErrorResponse(
                    format("Event with id %s does not exist", request.getId())), HttpStatus.BAD_REQUEST);
        }
        String uri = ServletUriComponentsBuilder.fromCurrentRequest().path(ID)
                .buildAndExpand(updateEvent.getId()).toUriString();
        UpdateEventResponse response = new UpdateEventResponse();
        response.add(new Link(uri));

        return new ResponseEntity<>(response, HttpStatus.ACCEPTED);
    }

    @ApiResponses({
            @ApiResponse(code = 200, message = "Success", response = EventExtendedResponse.class),
            @ApiResponse(code = 404, message = "Event not found"),
            @ApiResponse(code = 500, message = "Internal server error")
    })
    @GetMapping(value = "/event/{event-id}", produces = "application/json")
    public ResponseEntity<EventExtendedResponse> getEvent(@PathVariable("event-id") Long eventId) {
        Event event = eventService.getEvent(eventId);

        if (event != null) {
            String uri = ServletUriComponentsBuilder.fromCurrentRequest().path("").toUriString();
            EventExtendedResponse response = mapper.toEventExtendedResponse(event);
            response.add(new Link(uri));

            return new ResponseEntity<>(response, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @ApiResponses({
            @ApiResponse(code = 204, message = "Deleted"),
            @ApiResponse(code = 500, message = "Internal server error", response = ErrorResponse.class)
    })
    @DeleteMapping(value = "/event/{event-id}", produces = "application/json")
    public ResponseEntity deleteEvent(@PathVariable("event-id") Long eventId) {
        try {
            eventService.deleteEvent(eventId);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(
                    new ErrorResponse("Internal server error"), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @ApiResponses({
            @ApiResponse(code = 200, message = "Success", response = EventExtendedResponse[].class),
            @ApiResponse(code = 404, message = "Event not found"),
            @ApiResponse(code = 500, message = "Internal server error")
    })
    @GetMapping(value = "/event/title/{title}", produces = "application/json")
    public ResponseEntity<List<EventExtendedResponse>> getEventsByTitle(@PathVariable String title) {
        List<Event> events = eventService.getAllEventsByTitle(title);

        if (events.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        List<EventExtendedResponse> response = mapper.toEventExtendedResponse(events);

        for (EventExtendedResponse eventResponse : response) {
            String uri = ServletUriComponentsBuilder.fromCurrentContextPath().path("/l3/event-service/event/{id}")
                    .buildAndExpand(eventResponse.getId()).toUriString();
            eventResponse.add(new Link(uri));
        }
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}
