package com.epam.event.service.rest.mapper;

import com.epam.event.service.dto.model.Event;
import com.epam.event.service.dto.model.EventType;
import com.epam.event.service.rest.dto.EventExtendedResponse;
import com.epam.event.service.rest.dto.EventRequest;
import com.epam.event.service.rest.dto.EventResponse;
import com.epam.event.service.rest.dto.UpdateEventRequest;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

@Component
public class EventMapper {

    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm");

    public Event toEvent(EventRequest eventRequest) {
        if (eventRequest == null) {
            return null;
        }

        Event event = new Event();
        event.setId(eventRequest.getId());
        if (eventRequest.getDateTime() != null) {
            event.setDateTime(LocalDateTime.parse(eventRequest.getDateTime()));
        }
        if (eventRequest.getEventType() != null) {
            event.setEventType(EventType.valueOf(eventRequest.getEventType()));
        }
        event.setPlace(eventRequest.getPlace());
        event.setSpeaker(eventRequest.getSpeaker());
        event.setTitle(eventRequest.getTitle());

        return event;
    }

    public Event toEvent(UpdateEventRequest eventRequest) {
        if (eventRequest == null) {
            return null;
        }

        Event event = new Event();
        event.setId(eventRequest.getId());
        if (eventRequest.getDateTime() != null) {
            event.setDateTime(LocalDateTime.parse(eventRequest.getDateTime()));
        }
        if (eventRequest.getEventType() != null) {
            event.setEventType(EventType.valueOf(eventRequest.getEventType()));
        }
        event.setPlace(eventRequest.getPlace());
        event.setSpeaker(eventRequest.getSpeaker());
        event.setTitle(eventRequest.getTitle());

        return event;
    }

    public List<EventResponse> toEventResponse(List<Event> events) {
        if (events == null) {
            return null;
        }
        return events.stream()
                .map(this::toEventResponse)
                .collect(Collectors.toUnmodifiableList());
    }

    public EventResponse toEventResponse(Event event) {
        if (event == null) {
            return null;
        }

        EventResponse eventResponse = new EventResponse();
        eventResponse.setId(event.getId());

        if (event.getDateTime() != null) {
            eventResponse.setDateTime(FORMATTER.format(event.getDateTime()));
        }
        eventResponse.setEventType(event.getEventType().toString());
        eventResponse.setPlace(event.getPlace());
        eventResponse.setSpeaker(event.getSpeaker());
        eventResponse.setTitle(event.getTitle());
        return eventResponse;
    }

    public List<EventExtendedResponse> toEventExtendedResponse(List<Event> events) {
        if (events == null) {
            return null;
        }

        return events.stream()
                .map(this::toEventExtendedResponse)
                .collect(Collectors.toUnmodifiableList());
    }

    public EventExtendedResponse toEventExtendedResponse(Event event) {
        if (event == null) {
            return null;
        }

        EventExtendedResponse eventResponse = new EventExtendedResponse();
        eventResponse.setId(event.getId());

        if (event.getDateTime() != null) {
            eventResponse.setDateTime(FORMATTER.format(event.getDateTime()));
        }
        eventResponse.setEventType(event.getEventType().toString());
        eventResponse.setPlace(event.getPlace());
        eventResponse.setSpeaker(event.getSpeaker());
        eventResponse.setTitle(event.getTitle());
        return eventResponse;
    }
}
