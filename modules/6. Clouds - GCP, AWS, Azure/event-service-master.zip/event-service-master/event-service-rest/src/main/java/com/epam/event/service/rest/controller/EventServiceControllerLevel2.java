package com.epam.event.service.rest.controller;

import com.epam.event.service.api.service.EventService;
import com.epam.event.service.dto.model.Event;
import com.epam.event.service.rest.dto.CreateEventResponse;
import com.epam.event.service.rest.dto.ErrorResponse;
import com.epam.event.service.rest.dto.EventRequest;
import com.epam.event.service.rest.dto.EventResponse;
import com.epam.event.service.rest.dto.UpdateEventRequest;
import com.epam.event.service.rest.mapper.EventMapper;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

import static java.lang.String.format;

@RestController
@RequestMapping(value = "/l2/event-service")
public class EventServiceControllerLevel2 {

    private final EventService eventService;
    private final EventMapper mapper;

    public EventServiceControllerLevel2(EventService eventService, EventMapper mapper) {
        this.eventService = eventService;
        this.mapper = mapper;
    }

    @ApiResponses({
            @ApiResponse(code = 200, message = "Success"),
            @ApiResponse(code = 500, message = "Internal server error")
    })
    @GetMapping(value = "/event", produces = "application/json")
    public ResponseEntity<List<EventResponse>> getEvents() {
        List<Event> events = eventService.getAllEvents();
        List<EventResponse> response = mapper.toEventResponse(events);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @ApiResponses({
            @ApiResponse(code = 200, message = "Event created"),
            @ApiResponse(code = 500, message = "Internal server error")
    })
    @PostMapping(value = "/event", produces = "application/json")
    public ResponseEntity<CreateEventResponse> createEvent(@RequestBody EventRequest request) {
        Event event = mapper.toEvent(request);
        Event createdEvent = eventService.createEvent(event);

        return new ResponseEntity<>(new CreateEventResponse(createdEvent.getId()), HttpStatus.OK);
    }

    @ApiResponses({
            @ApiResponse(code = 204, message = "Event updated"),
            @ApiResponse(code = 400, message = "Bad request", response = ErrorResponse.class),
            @ApiResponse(code = 500, message = "Internal server error")
    })
    @ResponseStatus(value = HttpStatus.NO_CONTENT)
    @PutMapping(value = "/event", produces = "application/json")
    public ResponseEntity updateEvent(@RequestBody UpdateEventRequest request) {
        Event event = mapper.toEvent(request);
        Event updateEvent = eventService.updateEvent(event);

        if (updateEvent == null) {
            return new ResponseEntity<>(new ErrorResponse(
                    format("Event with id %s does not exist", request.getId())), HttpStatus.BAD_REQUEST);
        }
        return new ResponseEntity(HttpStatus.NO_CONTENT);
    }

    @ApiResponses({
            @ApiResponse(code = 200, message = "Success", response = EventResponse.class),
            @ApiResponse(code = 404, message = "Event not found"),
            @ApiResponse(code = 500, message = "Internal server error")
    })
    @GetMapping(value = "/event/{event-id}", produces = "application/json")
    public ResponseEntity<EventResponse> getEvent(@PathVariable("event-id") Long eventId) {
        Event event = eventService.getEvent(eventId);
        EventResponse response = mapper.toEventResponse(event);

        if (event != null) {
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @ApiResponses({
            @ApiResponse(code = 204, message = "Deleted"),
            @ApiResponse(code = 500, message = "Internal server error", response = ErrorResponse.class)
    })
    @ResponseStatus(value = HttpStatus.NO_CONTENT)
    @DeleteMapping(value = "/event/{event-id}", produces = "application/json")
    public ResponseEntity deleteEvent(@PathVariable("event-id") Long eventId) {
        try {
            eventService.deleteEvent(eventId);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(
                    new ErrorResponse("Internal server error"), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @ApiResponses({
            @ApiResponse(code = 200, message = "Success", response = EventResponse[].class),
            @ApiResponse(code = 404, message = "Event not found"),
            @ApiResponse(code = 500, message = "Internal server error")
    })
    @GetMapping(value = "/event/title/{title}", produces = "application/json")
    public ResponseEntity<List<EventResponse>> getEventsByTitle(@PathVariable String title) {
        List<Event> events = eventService.getAllEventsByTitle(title);

        if (events.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        List<EventResponse> response = mapper.toEventResponse(events);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

}
