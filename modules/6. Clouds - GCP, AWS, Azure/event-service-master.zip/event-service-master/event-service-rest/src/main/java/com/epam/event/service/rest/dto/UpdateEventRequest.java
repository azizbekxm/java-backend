package com.epam.event.service.rest.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class UpdateEventRequest {

    private Long id;
    private String dateTime;
    private String eventType;
    private String place;
    private String speaker;
    private String title;
}
