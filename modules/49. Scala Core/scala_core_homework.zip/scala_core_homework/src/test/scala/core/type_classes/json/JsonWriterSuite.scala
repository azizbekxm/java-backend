package core.type_classes.json

import org.scalatest.flatspec.AnyFlatSpec
import org.scalatest.matchers.should

class JsonWriterSuite extends AnyFlatSpec with should.Matchers {
  import JsonWriterInstances._

  val grisha: Person = Person("Grisha", 23)

  it should "convert string to json" in {
    Json.toJson("Hello world!") shouldBe JsString("Hello world!")
  }

  it should "convert option of person to json" in {
    Json.toJson(Option(grisha)) shouldBe JsObject(Map("name" -> JsString("Grisha"), "age" -> JsInteger(23)))
  }

  it should "convert empty value to JsNull" in {
    Json.toJson[Option[Person]](None) shouldBe JsNull
  }

  it should "work with syntax" in {
    import JsonSyntax._

    grisha.toJson shouldBe Json.toJson(grisha)
  }
}
