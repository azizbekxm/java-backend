package core.type_classes.json

object JsonWriterInstances {
  implicit val stringWriter: JsonWriter[String] = (value: String) => JsString(value)

  implicit val intWriter: JsonWriter[Int] = (value: Int) => JsInteger(value)

  // implement writer for person
  implicit val personWriter: JsonWriter[Person] = ???

  // implement writer for all options
  implicit def optionWriter[A](implicit writer: JsonWriter[A]): JsonWriter[Option[A]] = ???
}
