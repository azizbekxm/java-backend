package core.type_classes.json

case class Person(name: String, age: Int)
