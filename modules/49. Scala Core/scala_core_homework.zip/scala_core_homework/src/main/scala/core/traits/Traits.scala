package core.traits

object Traits {
  /*
  A binary tree of integers can be defined as follows:
  A Tree is a Node with a left and right Tree or a Leaf with an element of type Int.
  Implement this algebraic data type.
  Implement sum and double on Tree using polymorphism and pattern matching.
   */
  sealed trait Tree
  final case class Node(l: Tree, r: Tree) extends Tree
  final case class Leaf(elt: Int) extends Tree

  object TreeOps {
    def sum(tree: Tree): Int = ???

    def double(tree: Tree): Tree = ???
  }
}
