package core.collections

object Collections {
  /*
  Implement the function `tail` for removing the first element of a List.
  def tail[A](l: List[A]): List[A]
   */
  def tail[A](l: List[A]): List[A] = ???

  /*
  Generalize `tail` to the function drop, which removes the first n elements from a list.
  Note that this function takes time proportional only to the number of elements being
  dropped—we don’t need to make a copy of the entire List.
  def drop[A](l: List[A], n: Int): List[A]
   */
  def dropWhile[A](l: List[A], f: A => Boolean): List[A] = ???

  /*
  Implement a function, init, that returns a List consisting of all but the last element of a List.
  So, given List(1,2,3,4), init will return List(1,2,3).
  def init[A](l: List[A]): List[A]
   */
  def init[A](l: List[A]): List[A] = ???

}
