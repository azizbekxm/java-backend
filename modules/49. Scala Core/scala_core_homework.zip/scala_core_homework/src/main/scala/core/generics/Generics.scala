package core.generics

object Generics {

  /*
  sealed trait Tree
  final case class Node(l: Tree, r: Tree) extends Tree
  final case class Leaf(elt: Int) extends Tree

  A binary tree can be defined as follows:
  A Tree of type A is a Node with a left and right Tree or a Leaf with an element of type A.
  Implement this algebraic data type along with a fold method.
   */
  sealed trait Tree[A] {
    def fold[B](node: (B, B) => B, leaf: A => B): B
  }

}
