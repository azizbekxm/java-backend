package core.type_classes.json

object JsonSyntax {
  // implement interface method
  implicit class JsonWriterOps[A](value: A) {
    def toJson(implicit w: JsonWriter[A]): Json = ???
  }
}
