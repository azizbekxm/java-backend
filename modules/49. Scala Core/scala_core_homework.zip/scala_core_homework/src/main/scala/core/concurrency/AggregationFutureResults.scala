package core.concurrency

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

object AggregationFutureResults extends App {
  /*
  * implement a function, which return the result of the aggregation of executed Futures and exceptions
  * */
  def aggregate(seq: Seq[Future[String]]): Future[(Seq[Throwable], Seq[String])] = ???

  // test data
  val tasks = Seq(
    Future {
      Thread.sleep(1000)
      "red"
    },
    Future.failed(new RuntimeException("exception1")),
    Future.successful("blue"),
    Future.failed(new RuntimeException("exception2"))
  )

  val future = aggregate(tasks)
}
