package core.concurrency

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

object BatchedFutures extends App {
  /*
  * implement function which pass all elements from seq 'seq' throw function 'f'
  * divide all calculation on chunks with fixed size 'batchSize'
  * return result should be a future of sequence of result function 'f' on every element of 'seq'*/
  def batchedFutures[A, B](seq: Seq[A])(batchSize: Int)(f: A => Future[B]): Future[Seq[B]] =
    Future.sequence(seq.sliding(batchSize, batchSize).map(batch => Future.traverse(batch)(f))).map(_.flatten.toSeq)

  val xs: Seq[Int] = 1 to 100
  val func: Int => Future[Double] = (x: Int) => Future {
    Math.pow(x, 5)
  }
}