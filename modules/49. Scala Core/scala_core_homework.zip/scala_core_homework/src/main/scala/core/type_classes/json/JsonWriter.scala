package core.type_classes.json

trait JsonWriter[A] {
  def write(value: A): Json
}
