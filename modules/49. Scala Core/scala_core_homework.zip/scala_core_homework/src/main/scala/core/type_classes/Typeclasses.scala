package core.type_classes

/**
  * Semigroup is a typeclass which allows combining two values of type `T` into one
  */
trait Semigroup[T] {
  def combine(x: T, y: T): T
}
object Semigroup {
  def apply[T](implicit instance: Semigroup[T]): Semigroup[T] = instance
}

/**
  * Monoid extends @see Semigroup with a "default" value `unit`, which could be summoned out of thin air
  */
trait Monoid[T] extends Semigroup[T] {
  def unit: T
}
object Monoid {
  def apply[T](implicit instance: Monoid[T]): Monoid[T] = instance
}

/**
  * Functor allows changing value of type `A` in some context `F` with a pure function of type `A => B`.
  * You may also think of functors as a way of "lifting" pure functions `A => B` into context `F`, so
  * you get a function `F[A] => F[B]`
  */
trait Functor[F[_]] {
  def map[A, B](fa: F[A])(f: A => B): F[B]
  def lift[A, B](f: A => B): F[A] => F[B] = map(_)(f)
}
object Functor {
  def apply[F[_]](implicit instance: Functor[F]): Functor[F] = instance
}

/**
  * Pointed allows "wrapping" a pure value of type `T` into some context `F`
  */
trait Pointed[F[_]] {
  def pure[T](x: T): F[T]
}
object Pointed {
  def apply[F[_]](implicit instance: Pointed[F]): Pointed[F] = instance
}

/**
  * Apply allows applying (pun intended) a function in some context `F` (`F[A => B]`) to a value 
  * in the same context (`F[A]`), so you get `F[B]`
  */
trait Apply[F[_]] extends Functor[F] {
  def ap[A, B](fa: F[A])(fab: F[A => B]): F[B]
}
object Apply {
  def apply[F[_]](implicit instance: Apply[F]): Apply[F] = instance
}

/**
  * Applicative is a combination of @see Pointed and @see Apply
  */
trait Applicative[F[_]] extends Pointed[F] with Apply[F] {}
object Applicative {
  def apply[F[_]](implicit instance: Applicative[F]): Applicative[F] = instance
}

/**
  * Monad is a typeclass which allows sequential combination of computations in some context `F`
  */
trait Monad[F[_]] extends Applicative[F] {
  def flatten[A](ffa: F[F[A]]): F[A] = flatMap(ffa)(a => a)
  def flatMap[A, B](fa: F[A])(cont: A => F[B]): F[B] = flatten(map(fa)(cont))
  override def map[A, B](fa: F[A])(f: A => B): F[B] = flatMap(fa)(x => pure(f(x)))
}
object Monad {
  def apply[F[_]](implicit instance: Monad[F]): Monad[F] = instance
}

/**
  * Importing `syntax._` allows using methods and operators below directly on the target types:
  * 
  * @example
  * ```
  * import syntax._
  * 
  * val example1 = List[Int => String](_.toString) <*> List(1, 2, 3) // => List("1", "2", "3")
  * val example2 = for {
  *   x <- List(1, 2, 3)
  *   y <- List(x, x + 1, x + 2)
  * } yield y // => List(1, 2, 3, 2, 3, 4, 3, 4, 5)
  * ```
  */
object syntax {
  implicit class SemigroupOps[T](x: T)(implicit S: Semigroup[T]) {
    def |+|(y: T): T = S.combine(x, y)
  }

  implicit class MonoidOps[T](x: T)(implicit M: Monoid[T]) {
    def unit: T = M.unit
  }

  implicit class FunctorOps[F[_], A](fa: F[A])(implicit F: Functor[F]) {
    def map[B](f: A => B): F[B] = F.map(fa)(f)
  }

  implicit class PointedOps[F[_], A](x: A)(implicit P: Pointed[F]) {
    def pure: F[A] = P.pure(x)
  }

  implicit class ApplyOps[F[_], A, B](fab: F[A => B])(implicit Ap: Apply[F]) {
    def ap(fa: F[A]): F[B] = Ap.ap(fa)(fab)
    def <*>(fa: F[A]): F[B] = ap(fa)
  }

  implicit class MonadOps[F[_], A, B](fa: F[A])(implicit M: Monad[F]) {
    def flatMap(cont: A => F[B]): F[B] = M.flatMap(fa)(cont)
    def >>=(cont: A => F[B]): F[B] = flatMap(cont)
    def map(f: A => B) = M.map(fa)(f)
  }
}
