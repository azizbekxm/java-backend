package com.epam.ld.module2.testing.template;

/**
 * The type Template.
 */
public class Template {
}
