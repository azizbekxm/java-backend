package com.epam.ld.module2.testing;

public class MailServerTest {
}
