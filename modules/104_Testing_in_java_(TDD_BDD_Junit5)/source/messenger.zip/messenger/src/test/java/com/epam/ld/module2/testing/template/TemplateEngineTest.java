package com.epam.ld.module2.testing.template;

public class TemplateEngineTest {
}
